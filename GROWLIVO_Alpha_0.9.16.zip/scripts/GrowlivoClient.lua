-- GROWLIVO / Mobile-friendly clicker and pet inventory UI / Alpha 0.9.16
-- StarterPlayer > StarterPlayerScripts > GrowlivoClient [LocalScript]
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local player = Players.LocalPlayer
local Config = require(ReplicatedStorage:WaitForChild("GrowlivoConfig"))
local remotes = ReplicatedStorage:WaitForChild("GROWLIVO_Remotes")
local Action = remotes:WaitForChild("Action")
local Feedback = remotes:WaitForChild("Feedback")
local PetState = remotes:WaitForChild("PetState")
local OpenEggShop = remotes:WaitForChild("OpenEggShop")

local GOLD = Color3.fromRGB(255, 200, 67)
local BLUE = Color3.fromRGB(34, 202, 255)
local PANEL = Color3.fromRGB(22, 35, 60)
local DARK = Color3.fromRGB(13, 24, 44)
local WHITE = Color3.fromRGB(238, 248, 255)
local MUTED = Color3.fromRGB(172, 200, 224)

local gui = Instance.new("ScreenGui")
gui.Name = "GROWLIVO_HUD"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = player:WaitForChild("PlayerGui")

local function rounded(object, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius or 14)
    corner.Parent = object
    return object
end
local function outlined(object, color, width)
    local stroke = Instance.new("UIStroke")
    stroke.Thickness = width or 2
    stroke.Transparency = 0.25
    stroke.Color = color
    stroke.Parent = object
end
local function frame(name, parent, color)
    local f = Instance.new("Frame")
    f.Name = name
    f.BorderSizePixel = 0
    f.BackgroundColor3 = color or PANEL
    f.Parent = parent
    rounded(f)
    return f
end
local function text(name, parent, value, fontSize, color)
    local label = Instance.new("TextLabel")
    label.Name = name
    label.BorderSizePixel = 0
    label.BackgroundTransparency = 1
    label.Size = UDim2.fromScale(1, 1)
    label.Font = Enum.Font.GothamBold
    label.Text = value
    label.TextColor3 = color or WHITE
    label.TextSize = fontSize or 16
    label.TextWrapped = true
    label.Parent = parent
    return label
end
local function button(name, parent, value, color)
    local b = Instance.new("TextButton")
    b.Name = name
    b.Text = value
    b.TextColor3 = DARK
    b.TextSize = 17
    b.TextWrapped = true
    b.Font = Enum.Font.GothamBold
    b.BackgroundColor3 = color or GOLD
    b.BorderSizePixel = 0
    b.AutoButtonColor = true
    b.Parent = parent
    rounded(b, 12)
    return b
end
local function pretty(value)
    value = tonumber(value) or 0
    if value >= 1e12 then return string.format("%.2fT", value / 1e12) end
    if value >= 1e9 then return string.format("%.2fB", value / 1e9) end
    if value >= 1e6 then return string.format("%.2fM", value / 1e6) end
    if value >= 1e3 then return string.format("%.1fK", value / 1e3) end
    return tostring(math.floor(value))
end
local function attr(key)
    return player:GetAttribute(key) or 0
end

local title = text("Title", gui, "👑 GROWLIVO  •  " .. string.upper(Config.Version), 22, GOLD)
title.AnchorPoint = Vector2.new(0.5, 0)
title.Position = UDim2.new(0.5, 0, 0, 7)
title.Size = UDim2.fromOffset(330, 40)
title.TextStrokeTransparency = 0.55
local tapFlash = Instance.new("BindableEvent")
tapFlash.Name = "TapFlash"
tapFlash.Parent = gui

local stats = frame("Stats", gui, PANEL)
outlined(stats, BLUE)
local statPadding = Instance.new("UIPadding")
statPadding.PaddingLeft = UDim.new(0, 12)
statPadding.PaddingRight = UDim.new(0, 6)
statPadding.PaddingTop = UDim.new(0, 8)
statPadding.Parent = stats
local statLayout = Instance.new("UIListLayout")
statLayout.SortOrder = Enum.SortOrder.LayoutOrder
statLayout.Parent = stats
local statFields = {}
for i, name in ipairs({"Clicks", "Gems", "Rebirths", "Power", "Pets"}) do
    local label = text(name, stats, "—", 15, WHITE)
    label.Size = UDim2.new(1, 0, 0, 25)
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.LayoutOrder = i
    statFields[name] = label
end
local actions = frame("ActionPanel", gui, PANEL)
outlined(actions, GOLD)
local upgrade = button("Upgrade", actions, "УЛУЧШИТЬ", BLUE)
local rebirth = button("Rebirth", actions, "ПЕРЕРОЖДЕНИЕ", GOLD)
local petsButton = button("Pets", gui, "🐾 ПИТОМЦЫ", BLUE)
local menuToggle = button("CompactMenu", gui, "☰ МЕНЮ", BLUE)
menuToggle.TextSize = 13
menuToggle.Visible = false
player:SetAttribute("CompactMenuOpen", false) -- client HUD state, never trusted by the server
local clickButton = button("Click", gui, "+1 КЛИК", GOLD)
clickButton.TextSize = 29
outlined(clickButton, WHITE)

local toast = text("Toast", gui, "", 16, WHITE)
toast.AnchorPoint = Vector2.new(0.5, 1)
toast.TextStrokeTransparency = 0.2
local toastNonce = 0
local function message(value)
    toastNonce += 1
    local nonce = toastNonce
    toast.Text = tostring(value)
    task.delay(3, function()
        if nonce == toastNonce then
            toast.Text = ""
        end
    end)
end

local shade = frame("ModalBackdrop", gui, Color3.fromRGB(0, 0, 0))
shade.Size = UDim2.fromScale(1, 1)
shade.BackgroundTransparency = 0.25
shade.Visible = false
shade.ZIndex = 10
shade.Active = true
shade.ClipsDescendants = true
local modal = frame("PetsPanel", shade, PANEL)
modal.AnchorPoint = Vector2.new(0.5, 0.5)
modal.Position = UDim2.fromScale(0.5, 0.5)
modal.ZIndex = 11
outlined(modal, GOLD)
local heading = text("Heading", modal, "🐾  ПИТОМЦЫ И ЯЙЦА", 22, GOLD)
heading.Position = UDim2.fromOffset(12, 7)
heading.Size = UDim2.new(1, -72, 0, 46)
heading.ZIndex = 12
local close = button("Close", modal, "✕", GOLD)
close.AnchorPoint = Vector2.new(1, 0)
close.Position = UDim2.new(1, -12, 0, 10)
close.Size = UDim2.fromOffset(43, 38)
close.ZIndex = 12
local hatch = button("Hatch", modal, "🥚 ОТКРЫТЬ ЯЙЦО", BLUE)
hatch.Position = UDim2.new(0, 12, 0, 60)
hatch.Size = UDim2.new(0.64, -14, 0, 53)
hatch.TextSize = 15
hatch.ZIndex = 12
local hatch3 = button("Hatch3", modal, "🥚 ×3", GOLD)
hatch3.Position = UDim2.new(0.64, 4, 0, 60)
hatch3.Size = UDim2.new(0.36, -16, 0, 53)
hatch3.TextSize = 14
hatch3.ZIndex = 12
local odds = text("Odds", modal, "Шансы выпадения", 12, MUTED)
odds.Position = UDim2.new(0, 12, 0, 118)
odds.Size = UDim2.new(1, -24, 0, 37)
odds.ZIndex = 12
local inventoryTitle = text("InventoryTitle", modal, "ИНВЕНТАРЬ: 0/60   |   НАДЕТО: 0/3", 14, WHITE)
inventoryTitle.Position = UDim2.new(0, 12, 0, 160)
inventoryTitle.Size = UDim2.new(1, -24, 0, 28)
inventoryTitle.TextXAlignment = Enum.TextXAlignment.Left
inventoryTitle.ZIndex = 12
local scroll = Instance.new("ScrollingFrame")
scroll.Name = "Inventory"
scroll.Position = UDim2.new(0, 12, 0, 190)
scroll.Size = UDim2.new(1, -24, 1, -257)
scroll.BackgroundColor3 = DARK
scroll.BackgroundTransparency = 0.2
scroll.BorderSizePixel = 0
scroll.ScrollBarThickness = 5
scroll.ScrollBarImageColor3 = BLUE
scroll.CanvasSize = UDim2.fromOffset(0, 0)
scroll.ZIndex = 12
scroll.Parent = modal
rounded(scroll, 8)
local scrollPad = Instance.new("UIPadding")
scrollPad.PaddingTop = UDim.new(0, 7)
scrollPad.PaddingLeft = UDim.new(0, 8)
scrollPad.PaddingRight = UDim.new(0, 8)
scrollPad.Parent = scroll
local list = Instance.new("UIListLayout")
list.SortOrder = Enum.SortOrder.LayoutOrder
list.Padding = UDim.new(0, 6)
list.Parent = scroll
list:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
    scroll.CanvasSize = UDim2.fromOffset(0, list.AbsoluteContentSize.Y + 18)
end)
local best = button("EquipBest", modal, "⚡ НАДЕТЬ ЛУЧШИХ", GOLD)
best.AnchorPoint = Vector2.new(0, 1)
best.Position = UDim2.new(0, 12, 1, -12)
best.Size = UDim2.new(1, -24, 0, 47)
best.ZIndex = 12

local currentPets = {}
local currentEquipped = {}
local petsDirty = true
local pendingReleaseId = nil
local pendingReleaseButton = nil
local pendingReleaseNonce = 0
local function clearReleaseConfirmation()
    if pendingReleaseButton and pendingReleaseButton.Parent and pendingReleaseButton.Active then
        pendingReleaseButton.Text = "ОТПУСТИТЬ"
    end
    pendingReleaseId = nil
    pendingReleaseButton = nil
    pendingReleaseNonce += 1
end
local function repaintPets()
    petsDirty = false
    for _, child in ipairs(scroll:GetChildren()) do
        if child:IsA("Frame") then child:Destroy() end
    end
    local marked = {}
    for _, id in ipairs(currentEquipped) do marked[id] = true end
    inventoryTitle.Text = string.format("ИНВЕНТАРЬ: %d/%d   |   НАДЕТО: %d/%d", #currentPets, Config.MaxPetInventory, #currentEquipped, Config.MaxEquippedPets)
    if #currentPets == 0 then
        local empty = frame("Empty", scroll, DARK)
        empty.Size = UDim2.new(1, -4, 0, 55)
        empty.ZIndex = 13
        local info = text("Info", empty, "Пока нет питомцев. Открой первое яйцо!", 13, MUTED)
        info.ZIndex = 14
        return
    end
    for index, item in ipairs(currentPets) do
        local definition = Config.FindPet(item.Species)
        if definition then
            local row = frame("Pet_" .. tostring(item.Id), scroll, PANEL)
            row.Size = UDim2.new(1, -4, 0, 82)
            row.LayoutOrder = index
            row.ZIndex = 13
            local name = text("PetName", row, definition.Name .. "  •  +" .. tostring(definition.Bonus) .. "%", 14, definition.Color)
            name.Position = UDim2.fromOffset(9, 4)
            name.Size = UDim2.new(1, -18, 0, 25)
            name.TextXAlignment = Enum.TextXAlignment.Left
            name.ZIndex = 14
            local rarity = text("Rarity", row, definition.Rarity .. "  |  #" .. tostring(item.Id), 12, MUTED)
            rarity.Position = UDim2.fromOffset(9, 34)
            rarity.Size = UDim2.new(1, -180, 0, 38)
            rarity.TextXAlignment = Enum.TextXAlignment.Left
            rarity.ZIndex = 14
            local toggle = button("Toggle", row, marked[item.Id] and "СНЯТЬ" or "НАДЕТЬ", marked[item.Id] and GOLD or BLUE)
            toggle.Position = UDim2.new(1, -165, 1, -45)
            toggle.Size = UDim2.fromOffset(76, 38)
            toggle.TextSize = 11
            toggle.ZIndex = 14
            toggle.Activated:Connect(function()
                clearReleaseConfirmation()
                Action:FireServer("ToggleEquip", item.Id)
            end)
            local release = button("Release", row,
                marked[item.Id] and "НАДЕТ" or "ОТПУСТИТЬ", Color3.fromRGB(232, 124, 115))
            release.Position = UDim2.new(1, -85, 1, -45)
            release.Size = UDim2.fromOffset(77, 38)
            release.TextSize = 10
            release.ZIndex = 14
            release.Active = not marked[item.Id]
            release.AutoButtonColor = not marked[item.Id]
            release.BackgroundTransparency = marked[item.Id] and 0.5 or 0
            release.Activated:Connect(function()
                if player:GetAttribute("DataReady") ~= true or player:GetAttribute("DataStatus") ~= "Ready"
                    or marked[item.Id] or not release.Active then return end
                if pendingReleaseId == item.Id then
                    clearReleaseConfirmation()
                    Action:FireServer("ReleasePet", item.Id)
                    release.Text = "..."
                    release.Active = false
                else
                    clearReleaseConfirmation()
                    pendingReleaseId = item.Id
                    pendingReleaseButton = release
                    release.Text = "ТОЧНО?"
                    local nonce = pendingReleaseNonce
                    task.delay(4, function()
                        if pendingReleaseNonce == nonce and pendingReleaseId == item.Id then
                            clearReleaseConfirmation()
                            if release.Parent then release.Text = "ОТПУСТИТЬ" end
                        end
                    end)
                end
            end)
        end
    end
end

local function refreshEgg()
    local egg = Config.EggForWorld(player:GetAttribute("World") or "SkyCrown")
    if not egg then return end
    hatch.Text = "🥚 " .. egg.Name .. "\n" .. pretty(egg.Price)
    hatch3.Text = "🥚 ×3\n" .. pretty(egg.Price * Config.MaxHatchBatch)
    local pieces = {}
    for _, drop in ipairs(egg.Drops) do
        local pet = Config.FindPet(drop.Species)
        if pet then table.insert(pieces, pet.Name .. " " .. drop.Chance .. "%") end
    end
    odds.Text = table.concat(pieces, "  ·  ")
end

local function update()
    refreshEgg()
    statFields.Clicks.Text = "👆 Клики: " .. pretty(attr("Clicks"))
    statFields.Gems.Text = "💎 Кристаллы: " .. pretty(attr("Gems"))
    statFields.Rebirths.Text = "🔄 Перерождения: " .. pretty(attr("Rebirths"))
    statFields.Power.Text = "⚡ Сила клика: +" .. pretty(attr("ClickPower"))
    statFields.Pets.Text = "🐾 Питомцы: " .. pretty(attr("PetCount")) .. "  |  бонус +" .. pretty(attr("PetBonus")) .. "%"
    local cost = Config.UpgradeCost(attr("TapLevel"))
    upgrade.Text = cost and ("⚡ УЛУЧШИТЬ\n" .. pretty(cost) .. " кликов") or "МАКС. УРОВЕНЬ"
    local costR = Config.RebirthCost(attr("Rebirths"))
    rebirth.Text = costR and ("🔄 ПЕРЕРОДИТЬСЯ\n" .. pretty(costR) .. " кликов") or "МАКС. ПЕРЕРОЖДЕНИЯ"
    clickButton.Text = "+" .. pretty(attr("ClickPower")) .. " КЛИК"
    if player:GetAttribute("DataStatus") == "SaveRetry" then
        toast.Text = "Сохранение недоступно: действия приостановлены"
    elseif player:GetAttribute("DataStatus") == "Ready"
        and toast.Text == "Сохранение недоступно: действия приостановлены" then
        toast.Text = ""
    end
end

local function resize()
    local camera = workspace.CurrentCamera
    local viewport = camera and camera.ViewportSize or Vector2.new(1024, 768)
    local w, h = viewport.X, viewport.Y
    local mobile = w < 700
    local landscapeMenu = mobile and h < 500
    local menuOpen = player:GetAttribute("CompactMenuOpen") == true
    menuToggle.Visible = landscapeMenu
    if landscapeMenu then
        menuToggle.Position = UDim2.new(1, -106, 0, 5)
        menuToggle.Size = UDim2.fromOffset(96, 36)
        menuToggle.Text = menuOpen and "✕ ЗАКРЫТЬ" or "☰ МЕНЮ"
    end
    petsButton.Visible = not landscapeMenu or menuOpen
    clickButton.Visible = not landscapeMenu or not menuOpen
    actions.Visible = not landscapeMenu or not menuOpen
    if mobile then
        title.TextSize = 19
        if landscapeMenu then
            title.AnchorPoint = Vector2.new(0, 0)
            title.Position = UDim2.fromOffset(10, 7)
            title.Size = UDim2.new(1, -120, 0, 36)
            title.TextXAlignment = Enum.TextXAlignment.Left
        else
            title.AnchorPoint = Vector2.new(0.5, 0)
            title.Position = UDim2.new(0.5, 0, 0, 7)
            title.Size = UDim2.new(1, -20, 0, 36)
            title.TextXAlignment = Enum.TextXAlignment.Center
        end
        local compact = h < 650
        stats.Position = UDim2.fromOffset(12, 48)
        stats.Size = UDim2.new(1, -24, 0, compact and 110 or 134)
        for _, field in pairs(statFields) do field.Size = UDim2.new(1, 0, 0, compact and 20 or 25) end
        actions.AnchorPoint = Vector2.new(0, 1)
        actions.Position = UDim2.new(0, 12, 1, -10)
        actions.Size = UDim2.new(1, -24, 0, 66)
        upgrade.Position = UDim2.new(0, 7, 0, 7)
        upgrade.Size = UDim2.new(0.5, -10, 1, -14)
        rebirth.Position = UDim2.new(0.5, 3, 0, 7)
        rebirth.Size = UDim2.new(0.5, -10, 1, -14)
        upgrade.TextSize, rebirth.TextSize = 12, 12
        petsButton.Position = UDim2.new(1, -12, 0, compact and 163 or 187)
        petsButton.AnchorPoint = Vector2.new(1, 0)
        petsButton.Size = UDim2.fromOffset(math.min(w - 24, 162), 43)
        clickButton.AnchorPoint = Vector2.new(0.5, 1)
        clickButton.Position = UDim2.new(0.5, 0, 1, -94)
        clickButton.Size = UDim2.fromOffset(math.min(w - 32, 238), 73)
        toast.Position = UDim2.new(0.5, 0, 1, -171)
        toast.Size = UDim2.new(1, -20, 0, 42)
        modal.Size = UDim2.new(1, -24, 0, math.min(h - 28, 570))
        heading.TextSize = 18
        hatch.TextSize = 13
    else
        title.AnchorPoint = Vector2.new(0.5, 0)
        title.Position = UDim2.new(0.5, 0, 0, 7)
        title.TextXAlignment = Enum.TextXAlignment.Center
        title.TextSize = 22
        title.Size = UDim2.fromOffset(330, 40)
        stats.Position = UDim2.fromOffset(18, 58)
        stats.Size = UDim2.fromOffset(275, 137)
        for _, field in pairs(statFields) do field.Size = UDim2.new(1, 0, 0, 25) end
        actions.AnchorPoint = Vector2.new(1, 0)
        actions.Position = UDim2.new(1, -18, 0, 58)
        actions.Size = UDim2.fromOffset(245, 171)
        upgrade.Position = UDim2.fromOffset(9, 9)
        upgrade.Size = UDim2.new(1, -18, 0, 72)
        rebirth.Position = UDim2.fromOffset(9, 90)
        rebirth.Size = UDim2.new(1, -18, 0, 72)
        upgrade.TextSize, rebirth.TextSize = 15, 15
        petsButton.AnchorPoint = Vector2.new(1, 0)
        petsButton.Position = UDim2.new(1, -18, 0, 239)
        petsButton.Size = UDim2.fromOffset(245, 50)
        clickButton.AnchorPoint = Vector2.new(0.5, 1)
        clickButton.Position = UDim2.new(0.5, 0, 1, -20)
        clickButton.Size = UDim2.fromOffset(285, 85)
        toast.Position = UDim2.new(0.5, 0, 1, -115)
        toast.Size = UDim2.fromOffset(440, 42)
        modal.Size = UDim2.fromOffset(math.min(w - 90, 560), math.min(h - 80, 590))
        heading.TextSize = 22
        hatch.TextSize = 16
    end
end

local function ready()
    return player:GetAttribute("DataReady") == true
        and player:GetAttribute("DataStatus") == "Ready"
end
local lastTap = -100
local function click()
    if not ready() or shade.Visible or player:GetAttribute("SettingsOpen") == true
        or player:GetAttribute("CompactMenuOpen") == true then return end
    local now = os.clock()
    if now - lastTap < (1 / Config.MaxClicksPerSecond) then return end
    lastTap = now
    Action:FireServer("Click")
    tapFlash:Fire(attr("ClickPower"))
end
clickButton.Activated:Connect(click)
menuToggle.Activated:Connect(function()
    player:SetAttribute("CompactMenuOpen", player:GetAttribute("CompactMenuOpen") ~= true)
end)
player:GetAttributeChangedSignal("CompactMenuOpen"):Connect(resize)
UserInputService.InputBegan:Connect(function(input, handled)
    if not handled and not UserInputService:GetFocusedTextBox()
        and input.KeyCode == Enum.KeyCode.Space then click() end
end)
upgrade.Activated:Connect(function()
    if ready() then Action:FireServer("Upgrade") end
end)
rebirth.Activated:Connect(function()
    if ready() then Action:FireServer("Rebirth") end
end)
local function openPets()
    player:SetAttribute("CompactMenuOpen", false)
    shade.Visible = true
    if petsDirty then repaintPets() end
    if ready() then Action:FireServer("GetPets") end
end
petsButton.Activated:Connect(openPets)
OpenEggShop.OnClientEvent:Connect(openPets)
close.Activated:Connect(function()
    clearReleaseConfirmation()
    shade.Visible = false
end)
hatch.Activated:Connect(function()
    if ready() then Action:FireServer("Hatch") end
end)
hatch3.Activated:Connect(function()
    if ready() then Action:FireServer("Hatch3") end
end)
best.Activated:Connect(function()
    if ready() then Action:FireServer("EquipBest") end
end)
Feedback.OnClientEvent:Connect(function(info)
    if typeof(info) == "string" then message(info) end
end)
PetState.OnClientEvent:Connect(function(inventory, equipped)
    if typeof(inventory) ~= "table" or typeof(equipped) ~= "table" then return end
    clearReleaseConfirmation()
    currentPets = inventory
    currentEquipped = equipped
    petsDirty = true
    if shade.Visible then repaintPets() end
end)

-- Several attributes change during one server sync. Redraw HUD only once
-- in the next scheduler slice instead of rebuilding labels for every field.
local updateQueued = false
local function scheduleUpdate()
    if updateQueued then return end
    updateQueued = true
    task.defer(function()
        updateQueued = false
        if gui.Parent then update() end
    end)
end
for _, key in ipairs({"Clicks", "Gems", "Rebirths", "TapLevel", "ClickPower", "PetBonus", "PetCount", "DataReady", "SavingEnabled", "DataStatus", "World"}) do
    player:GetAttributeChangedSignal(key):Connect(scheduleUpdate)
end
player:GetAttributeChangedSignal("DataReady"):Connect(function()
    if ready() then Action:FireServer("GetPets") end
end)
resize()
update()
if ready() then Action:FireServer("GetPets") end
local viewportConnection
local function cameraChanged()
    if viewportConnection then viewportConnection:Disconnect() end
    viewportConnection = nil
    resize()
    local camera = workspace.CurrentCamera
    if camera then
        viewportConnection = camera:GetPropertyChangedSignal("ViewportSize"):Connect(resize)
    end
end
cameraChanged()
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(cameraChanged)
