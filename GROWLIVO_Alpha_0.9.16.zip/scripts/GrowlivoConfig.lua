-- GROWLIVO / Shared economy and progression config / Alpha 0.9.16
local Config = {}
Config.Version = "Alpha 0.9.16"
Config.ProfileVersion = 7
Config.MaxSerializedProfileBytes = 3000000 -- under the DataStore value limit; conservative safety margin
Config.TutorialClickGoal = 20
Config.DataStoreName = "GROWLIVO_Profiles_v1" -- migration from 0.1/0.2; do not rename
Config.AutosaveSeconds = 90
Config.DirtySaveDelaySeconds = 8 -- post-UpdateAsync changes should not wait 90 s
Config.SaveRetrySeconds = 12 -- fast retry for transient storage failures
Config.SaveWaitTimeoutSeconds = 20 -- bounded wait for in-flight write
Config.SessionLockSeconds = 240
Config.MaxClicksPerSecond = 8
-- Per-player Action RemoteEvent capacity and refill rate. On top of action-specific cooldowns.
Config.RemoteBurstCapacity = 30
Config.RemoteTokensPerSecond = 20
Config.SaveRetryMaxSeconds = 60 -- bounded backoff after repeated DataStore failures
Config.MaxClickBalance = 1000000000000
Config.MaxTotalClicks = 9000000000000000
Config.MaxGems = 1000000000
Config.MaxTapLevel = 50
Config.MaxRebirths = 1000
Config.MaxPetInventory = 60
Config.MaxHatchBatch = 3
Config.MaxEquippedPets = 3
Config.EggPrice = 150 -- compatibility with old UI/tests
Config.DefaultSettings = {ShowPets = true, Effects = true, ReducedMotion = false, Sounds = true}

-- Deterministic UTC schedule shared across servers. Active first 10 minutes of every hour.
-- Nothing in the payload from a client can change the clock, reward, multiplier or progress.
Config.Starfall = {
    Name = "Звёздный дождь", CycleSeconds = 3600, ActiveSeconds = 600,
    Multiplier = 2, Goal = 60, RewardClicks = 500, RewardGems = 20,
}
function Config.StarfallAt(now)
    local clock = math.max(0, math.floor(now))
    local offset = clock % Config.Starfall.CycleSeconds
    local active = offset < Config.Starfall.ActiveSeconds
    local remaining = active and (Config.Starfall.ActiveSeconds - offset)
        or (Config.Starfall.CycleSeconds - offset)
    return active, remaining, active and Config.Starfall.Multiplier or 1
end

-- Add your own numeric Roblox UserId to enable the admin panel. Never trust client checks.
Config.AdminUserIds = {} -- Example: {123456789}; intentionally empty on release
Config.Leaderboards = {
    TotalClicksStore = "GROWLIVO_TopTotalClicks_v1",
    RebirthsStore = "GROWLIVO_TopRebirths_v1",
    PageSize = 10,
    RefreshSeconds = 120,
}


Config.Worlds = {
    {Id = "SkyCrown", Name = "Небесная корона", Multiplier = 1, UnlockRebirths = 0, UnlockGems = 0, EggId = "SkyEgg"},
    {Id = "CrystalVale", Name = "Кристальная долина", Multiplier = 2, UnlockRebirths = 1, UnlockGems = 25, EggId = "CrystalEgg"},
}
local worldById = {}
for _, world in ipairs(Config.Worlds) do worldById[world.Id] = world end
function Config.FindWorld(id) return typeof(id) == "string" and worldById[id] or nil end

Config.Pets = {
    {Id = "CloudBunny", Name = "Облачный зайчик", Rarity = "Обычный", Bonus = 10, Color = Color3.fromRGB(237, 245, 255)},
    {Id = "SunFox", Name = "Солнечный лис", Rarity = "Необычный", Bonus = 20, Color = Color3.fromRGB(255, 189, 84)},
    {Id = "SkyOwl", Name = "Небесная сова", Rarity = "Редкий", Bonus = 35, Color = Color3.fromRGB(105, 209, 255)},
    {Id = "CrystalCat", Name = "Кристальный кот", Rarity = "Эпический", Bonus = 65, Color = Color3.fromRGB(152, 108, 255)},
    {Id = "CrownDragon", Name = "Коронованный дракон", Rarity = "Легендарный", Bonus = 120, Color = Color3.fromRGB(255, 207, 51)},
    {Id = "GemSlime", Name = "Самоцветный слайм", Rarity = "Обычный", Bonus = 45, Color = Color3.fromRGB(60, 234, 216)},
    {Id = "PrismDeer", Name = "Призматический олень", Rarity = "Редкий", Bonus = 80, Color = Color3.fromRGB(186, 151, 255)},
    {Id = "AzurePhoenix", Name = "Лазурный феникс", Rarity = "Эпический", Bonus = 155, Color = Color3.fromRGB(46, 181, 255)},
    {Id = "DiamondWyrm", Name = "Алмазный змей", Rarity = "Мифический", Bonus = 260, Color = Color3.fromRGB(255, 242, 168)},
}
local petById = {}
for _, pet in ipairs(Config.Pets) do petById[pet.Id] = pet end
function Config.FindPet(id) return typeof(id) == "string" and petById[id] or nil end

-- Only the server chooses the egg and rolls the odds.
Config.Eggs = {
    SkyEgg = {Name = "Небесное яйцо", Price = 150, World = "SkyCrown", Drops = {
        {Species = "CloudBunny", Chance = 45}, {Species = "SunFox", Chance = 28},
        {Species = "SkyOwl", Chance = 17}, {Species = "CrystalCat", Chance = 8},
        {Species = "CrownDragon", Chance = 2},
    }},
    CrystalEgg = {Name = "Кристальное яйцо", Price = 2500, World = "CrystalVale", Drops = {
        {Species = "GemSlime", Chance = 50}, {Species = "PrismDeer", Chance = 30},
        {Species = "AzurePhoenix", Chance = 15}, {Species = "DiamondWyrm", Chance = 5},
    }},
}
function Config.EggForWorld(worldId)
    local world = Config.FindWorld(worldId)
    return world and Config.Eggs[world.EggId] or nil
end

-- All goals are repeatable after UTC midnight; progress tracks actions, not purchased rewards.
Config.Quests = {
    {Id = "Tap80", Name = "80 нажатий", Event = "Tap", Goal = 80, Gems = 8},
    {Id = "Egg2", Name = "Открыть 2 яйца", Event = "Hatch", Goal = 2, Gems = 7},
    {Id = "Upgrade3", Name = "Купить 3 улучшения", Event = "Upgrade", Goal = 3, Gems = 5},
    {Id = "Rebirth1", Name = "Сделать перерождение", Event = "Rebirth", Goal = 1, Gems = 10},
}
-- Weekly quests use a single UTC Monday key, not the player's local clock.
-- A manual tap increments by one even when a world/Starfall multiplies its value.
Config.WeeklyQuests = {
    {Id = "WeekTap750", Name = "750 нажатий за неделю", Event = "Tap", Goal = 750, Gems = 35},
    {Id = "WeekHatch10", Name = "Открыть 10 яиц", Event = "Hatch", Goal = 10, Gems = 40},
    {Id = "WeekUpgrade10", Name = "Купить 10 улучшений", Event = "Upgrade", Goal = 10, Gems = 30},
    {Id = "WeekRebirth2", Name = "Сделать 2 перерождения", Event = "Rebirth", Goal = 2, Gems = 55},
}
local weeklyQuestById = {}
for _, quest in ipairs(Config.WeeklyQuests) do weeklyQuestById[quest.Id] = quest end
function Config.FindWeeklyQuest(id)
    return typeof(id) == "string" and weeklyQuestById[id] or nil
end
local questById = {}
for _, quest in ipairs(Config.Quests) do questById[quest.Id] = quest end
function Config.FindQuest(id) return typeof(id) == "string" and questById[id] or nil end
Config.DailyReward = {Clicks = 300, Gems = 10}

Config.Achievements = {
    {Id = "FirstSteps", Name = "Первые 500 кликов", Stat = "TotalClicks", Goal = 500, Gems = 10},
    {Id = "PetCollector", Name = "Открыть 10 яиц", Stat = "HatchedTotal", Goal = 10, Gems = 15},
    {Id = "RebirthMaster", Name = "Сделать 5 перерождений", Stat = "Rebirths", Goal = 5, Gems = 25},
}
local achievementById = {}
for _, achievement in ipairs(Config.Achievements) do achievementById[achievement.Id] = achievement end
function Config.FindAchievement(id) return typeof(id) == "string" and achievementById[id] or nil end

function Config.PetBonus(inventory, equipped)
    if typeof(inventory) ~= "table" or typeof(equipped) ~= "table" then return 0 end
    local owned = {}
    for _, item in ipairs(inventory) do owned[item.Id] = item.Species end
    local bonus = 0
    for _, id in ipairs(equipped) do
        local pet = Config.FindPet(owned[id])
        if pet then bonus += pet.Bonus end
    end
    return bonus
end
function Config.ClickPower(tapLevel, rebirths, petBonus, worldMultiplier)
    local level = math.max(1, math.floor(tapLevel))
    local rebirth = 1 + math.max(0, math.floor(rebirths))
    local bonus = math.max(0, math.floor(petBonus or 0))
    local world = math.clamp(math.floor(worldMultiplier or 1), 1, 100)
    return math.max(1, math.floor(level * rebirth * (100 + bonus) / 100 * world))
end
function Config.UpgradeCost(level)
    if level >= Config.MaxTapLevel then return nil end
    return math.floor(25 * (1.55 ^ (level - 1)))
end
function Config.RebirthCost(rebirths)
    if rebirths >= Config.MaxRebirths then return nil end
    return 500 * ((rebirths + 1) ^ 2)
end
function Config.RebirthGemReward(rebirths)
    return 5 + 2 * math.max(0, rebirths)
end
return Config
